. 'scripts/01. Load modules.ps1'
. 'scripts/02. Load data.ps1'

### Loading Azure subscription
Write-Host "Loading Azure subscription $subscription_Name ... " -NoNewline;
Write-Host "STARTED" -ForegroundColor Yellow;
Try
{
	Select-AzureSubscription –SubscriptionName $subscription_Name

    Write-Host "Loading Azure subscription $subscription_Name ... " -NoNewline;
	Write-Host "DONE" -ForegroundColor Green;
}
Catch [Exception]
{
    Write-Host "Loading Azure subscription $subscription_Name ... " -NoNewline;
	Write-Host "FAILED" -ForegroundColor Red;
    Write-Host "Error during 03. Create infrastructure execution" -ForegroundColor Red;
    Write-Host $_.Exception.Message -ForegroundColor Red;
	Break;
}

### Stopping VMs
Write-Host "Stopping VMs ... " -NoNewline;
Write-Host "STARTED" -ForegroundColor Yellow;
Try
{
	Write-Host "Stopping VM $cloudservice_Name.$sharepoint_Name ... ";
	Stop-AzureVM -ServiceName $cloudservice_Name -Name $sharepoint_Name -Force
	
	Write-Host "Stopping VM $cloudservice_Name.$sqlServer_Name ... ";
	Stop-AzureVM -ServiceName $cloudservice_Name -Name $sqlServer_Name -Force
	
	Write-Host "Stopping VM $cloudservice_Name.$activeDirectory_Name ... ";
	Stop-AzureVM -ServiceName $cloudservice_Name -Name $activeDirectory_Name -Force
	
    Write-Host "Stopping VMs ... " -NoNewline;
	Write-Host "DONE" -ForegroundColor Green;
}
Catch [Exception]
{
    Write-Host "Stopping VMs ... " -NoNewline;
	Write-Host "FAILED" -ForegroundColor Red;
    Write-Host $_.Exception.Message -ForegroundColor Red;
	Break;
}



### Exporting VMs
Write-Host "Exporting VMs ... " -NoNewline;
Write-Host "STARTED" -ForegroundColor Yellow;
Try
{
	Write-Host "Exporting VM $cloudservice_Name.$activeDirectory_Name ... ";
	Export-AzureVM -ServiceName $cloudservice_Name -name $activeDirectory_Name -Path "$exportPath\$cloudservice_Name.$activeDirectory_Name.xml"
	
	Write-Host "Exporting VM $cloudservice_Name.$sqlServer_Name ... ";
	Export-AzureVM -ServiceName $cloudservice_Name -name $sqlServer_Name -Path "$exportPath\$cloudservice_Name.$sqlServer_Name.xml"

	Write-Host "Exporting VM $cloudservice_Name.$sharepoint_Name ... ";
	Export-AzureVM -ServiceName $cloudservice_Name -name $sharepoint_Name -Path "$exportPath\$cloudservice_Name.$sharepoint_Name.xml"

    Write-Host "Exporting VMs ... " -NoNewline;
	Write-Host "DONE" -ForegroundColor Green;
}
Catch [Exception]
{
    Write-Host "Exporting VMs ... " -NoNewline;
	Write-Host "FAILED" -ForegroundColor Red;
    Write-Host $_.Exception.Message -ForegroundColor Red;
	Break;
}



### Removing VMs
Write-Host "Removing VMs ... " -NoNewline;
Write-Host "STARTED" -ForegroundColor Yellow;
Try
{
	Write-Host "Removing VM $cloudservice_Name.$activeDirectory_Name ... ";
	Remove-AzureVM -ServiceName $cloudservice_Name -name $activeDirectory_Name 
	
	Write-Host "Removing VM $cloudservice_Name.$sqlServer_Name ... ";
	Remove-AzureVM -ServiceName $cloudservice_Name -name $sqlServer_Name 

	Write-Host "Removing VM $cloudservice_Name.$sharepoint_Name ... ";
	Remove-AzureVM -ServiceName $cloudservice_Name -name $sharepoint_Name 
	
    Write-Host "Removing VMs ... " -NoNewline;
	Write-Host "DONE" -ForegroundColor Green;
}
Catch [Exception]
{
    Write-Host "Removing VMs ... " -NoNewline;
	Write-Host "FAILED" -ForegroundColor Red;
    Write-Host $_.Exception.Message -ForegroundColor Red;
	Break;
}



Write-Host "Everything done succesfully ... " -NoNewline;
Write-Host "MAYBE" -ForegroundColor Green;