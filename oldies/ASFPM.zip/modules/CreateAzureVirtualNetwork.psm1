function CreateAzureVirtualNetwork([string]$vNet_Name, [string]$vNet_AddressPrefix, [string]$vNet_Dns_Name, [string]$vNet_Dns_Ip, [string]$vNet_Subnet_Name,[string]$vNet_Subnet_AddressPrefix, [string]$affinityGroup_Name)
{
	$config = Get-AzureVNetConfig;
    

    # Loading XML
    if ($config -ne $null)
    {
        [xml]$xmlConfig = $config.XMLConfiguration;
        $ns = New-Object System.Xml.XmlNamespaceManager($xmlConfig.NameTable);
        $namespace = $xmlConfig.DocumentElement.NamespaceURI;
        $ns.AddNamespace("ns", $namespace);
    }
    else
    {
        [xml]$xmlConfig = New-Object xml; 
        $xmlDeclaration = $xmlConfig.CreateXmlDeclaration("1.0", "utf-8", $null);
        $xmlConfig.AppendChild($xmlDeclaration) | Out-Null;
        $ns = New-Object System.Xml.XmlNamespaceManager($xmlConfig.NameTable);
        $namespace = "http://schemas.microsoft.com/ServiceHosting/2011/07/NetworkConfiguration";        
        $ns.AddNamespace("ns", $namespace);
    }
    
    
    # Adjusting XML
    $netCfgRoot = $xmlConfig.SelectNodes("//ns:NetworkConfiguration", $ns)[0];
    if ($netCfgRoot -eq $null)
    {
        $netCfgRoot = $xmlConfig.CreateElement("NetworkConfiguration", $namespace);
        $netCfgRoot.SetAttribute("xmlns:xsd","http://www.w3.org/2001/XMLSchema")
        $netCfgRoot.SetAttribute("xmlns:xsi","http://www.w3.org/2001/XMLSchema-instance")
        $xmlConfig.AppendChild($netCfgRoot);
    }
 
    $vNetCfg = $xmlConfig.SelectNodes("//ns:VirtualNetworkConfiguration", $ns)[0];
    if ($vNetCfg -eq $null)
    {
        $vNetCfg = $xmlConfig.CreateElement("VirtualNetworkConfiguration", $namespace);
        $netCfgRoot.AppendChild($vNetCfg);
    }
 

    # Creating nodes
    $newDnsCreated = $false;
    $newDns = $xmlConfig.SelectSingleNode("//ns:DnsServer[@name='$vNet_Dns_Name']", $ns);
    If ($newDns -eq $null)
    {
        $dns = $xmlConfig.SelectNodes("//ns:Dns", $ns)[0];
        If ($dns -eq $null)
        {
            $dns = $xmlConfig.CreateElement("Dns", $namespace);
            $vNetCfg.AppendChild($dns);
        }
        
        $dnsServers = $xmlConfig.SelectNodes("//ns:DnsServers", $ns)[0]
        If ($dnsServers -eq $null)
        {
            $dnsServers = $xmlConfig.CreateElement("DnsServers", $namespace);
            $dns.AppendChild($dnsServers);
        }

        $newDns = $xmlConfig.CreateElement("DnsServer", $namespace);
        $newDns.SetAttribute("name",$vNet_Dns_Name);
	    $newDns.SetAttribute("IPAddress",$vNet_Dns_Ip);
        $dnsServers.AppendChild($newDns);

        $newDnsCreated = $true;
    }

    $newNetworkCreated = $false;
    $newNetworkSite = $xmlConfig.SelectSingleNode("//ns:VirtualNetworkSite[@name='$vNet_Name']", $ns);
    If ($newNetworkSite -eq $null)
    {
        $virtualNetworkSites = $xmlConfig.SelectNodes("//ns:VirtualNetworkSites", $ns)[0]
        If ($virtualNetworkSites -eq $null)
        {
            $virtualNetworkSites = $xmlConfig.CreateElement("VirtualNetworkSites", $namespace);
            $vNetCfg.AppendChild($virtualNetworkSites);
        }

	    $newNetworkSite = $xmlConfig.CreateElement("VirtualNetworkSite", $namespace);
	    $newNetworkSite.SetAttribute("name",$vNet_Name);
	    $newNetworkSite.SetAttribute("AffinityGroup",$affinityGroup_Name);
        $virtualNetworkSites.AppendChild($newNetworkSite);

        $addressSpace = $xmlConfig.CreateElement("AddressSpace", $namespace);
        $newNetworkSite.AppendChild($addressSpace);

        $addressSpaceAddressPrefix = $xmlConfig.CreateElement("AddressPrefix", $namespace);
        $addressSpaceAddressPrefix.InnerText="10.0.0.0/20"
        $addressSpace.AppendChild($addressSpaceAddressPrefix);

        $subnets = $xmlConfig.CreateElement("Subnets", $namespace);
        $newNetworkSite.AppendChild($subnets);

        $subnet = $xmlConfig.CreateElement("Subnet", $namespace);
        $subnet.SetAttribute("name",$vNet_Subnet_Name);
        $subnets.AppendChild($subnet);

        $subnetAddressPrefix = $xmlConfig.CreateElement("AddressPrefix", $namespace);
        $subnetAddressPrefix.InnerText="10.0.0.0/24"
        $subnet.AppendChild($subnetAddressPrefix);
    
        $dnsServersRef = $xmlConfig.CreateElement("DnsServersRef", $namespace);
        $newNetworkSite.AppendChild($dnsServersRef);
   
        $dnsServerRef = $xmlConfig.CreateElement("DnsServerRef", $namespace);
        $dnsServerRef.SetAttribute("name",$vNet_Dns_Name);
        $dnsServersRef.AppendChild($dnsServerRef);

        $newNetworkCreated = $true;
    }



    If ($newDnsCreated -eq $true -or $newNetworkCreated -eq $true)
    {
        $tempNetConfig = $env:TEMP + "\NewVNetConfig.netcfg"
        $xmlConfig.Save($tempNetConfig);
    
        Set-AzureVNetConfig -ConfigurationPath $tempNetConfig;
    }
}