function CreateADUser([string]$loginName, [string]$name, [string]$surname, [string]$displayName, [string]$password, [string]$email)
{
    $pwd = ConvertTo-SecureString -String $password -AsPlainText -Force 
    New-Aduser -UserPrincipalName $loginName -Name $loginName -SamAccountName $loginName -GivenName $name -Surname $surname -DisplayName $displayName -AccountPassword $pwd -EmailAddress $email -CannotChangePassword $true -PasswordNeverExpires $true -Enabled $true
}