function WaitForBoot([string]$serviceName,[string]$vmName)
{
    $startDate = Get-Date;
    $endDate = $startDate;

    do
    {
        $vm = get-azurevm -ServiceName $serviceName -Name $vmName
        if($vm -eq $null)
        {
            Write-Host "Wait for boot: no connection with $vmName@$serviceName";
            return;
        }
        if(($vm.InstanceStatus -eq "FailedStartingVM") -or ($vm.InstanceStatus -eq "ProvisioningFailed") -or ($vm.InstanceStatus -eq "ProvisioningTimeout"))
        {
            Write-Host "Wait for boot: provisioning failed for $vmName@$serviceName";
            return;
        }
        if($vm.InstanceStatus -eq "ReadyRole")
        {
            return;
        }

        $endDate = Get-Date;
        $t = New-TimeSpan –Start $startDate –End $endDate

        Write-Host "Wait for boot: waiting since $t for $vmName@$serviceName";
        Start-Sleep 30;
    }while($true)
}