function GetAzureLatestImage([string]$imageLabel)
{
   $images = Get-AzureVMImage | where { $_.Label -eq $imageLabel } | Sort-Object -Descending -Property PublishedDate
   return $images[0].ImageName
}