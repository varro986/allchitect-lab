function CreateAzureVM([string]$vm_Name, [string]$vm_Size, [string]$vm_Image, [string]$vNet_Name, [string]$subnet_Name, [string]$admin_Username, [string]$admin_Password, [string]$cloudService_Name, [string]$affinityGroup_Name, [string]$domain_Name, [string]$domain_NetBiosName, [string]$domainAdmin_Name, [string]$domainAdmin_Password, [string]$vm_Ip)
{
	if(($domain_Name -eq "") -or ($domainAdmin_Name -eq "") -or ($domainAdmin_Password -eq "") -or ($domain_NetBiosName -eq ""))
	{
		$vmConfig = New-AzureVMConfig -Name $vm_Name -InstanceSize $vm_Size -ImageName $vm_Image | Add-AzureProvisioningConfig -Windows -Password $admin_Password -AdminUsername $admin_Username | Set-AzureSubnet $subnet_Name | Set-AzureStaticVNetIP -IPAddress $vm_Ip;
        $vmConfig | New-AzureVM -ServiceName $cloudService_Name -VNetName $vNet_Name -WaitForBoot -Verbose;
	}
	else
	{
		$vmConfig = New-AzureVMConfig -Name $vm_Name -InstanceSize $vm_Size -ImageName $vm_Image | `
	                Add-AzureProvisioningConfig -WindowsDomain -Password $admin_Password -AdminUsername $admin_Username -JoinDomain $domain_Name `
	                -Domain $domain_NetBiosName -DomainUserName $domainAdmin_Name -DomainPassword $domainAdmin_Password | Set-AzureSubnet -SubnetNames $subnet_Name | Set-AzureStaticVNetIP -IPAddress $vm_Ip;
        $vmConfig | New-AzureVM -ServiceName $cloudService_Name -VNetName $vNet_Name -WaitForBoot -Verbose;
	}
}
