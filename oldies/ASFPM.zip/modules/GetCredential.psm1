function GetCredential([string]$username,[string]$password)
{
    $pwd = ConvertTo-SecureString -String $password -AsPlainText -Force 
    $credential = New-Object -TypeName System.Management.Automation.PSCredential -ArgumentList $username, $pwd

	return $credential
}
