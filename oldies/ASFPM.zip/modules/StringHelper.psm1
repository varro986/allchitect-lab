function RaiseExceptionIfNullOrEmpty([string]$s)
{
	If ([string]::IsNullOrEmpty($s))
	{
		Throw "$s";
	}
	Else
	{
		return $s;
	}
}