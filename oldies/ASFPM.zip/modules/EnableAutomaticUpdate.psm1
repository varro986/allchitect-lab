function EnableAutomaticUpdate([bool]$enable)
{
	$settings = (New-Object -com "Microsoft.Update.AutoUpdate").Settings
	
	if ($enable == $true)
	{
		$settings.NotificationLevel = 4
	}
	else
	{
		$settings.NotificationLevel = 1
	}
	
	$settings.Save
}