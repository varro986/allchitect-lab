. 'scripts/01. Load modules.ps1'
. 'scripts/02. Load data.ps1'
. 'scripts/03. Create infrastructure.ps1'
. 'scripts/04. Create Active directory VM.ps1'
. 'scripts/05. Configure Active directory.ps1'
. 'scripts/06. Create SQL server VM.ps1'
. 'scripts/07. Configure SQL server.ps1'
. 'scripts/08. Create SharePoint VM.ps1'
. 'scripts/09. Configure SharePoint.ps1'
. 'scripts/10. Configure SharePoint Service App.ps1'


Write-Host "Everything done succesfully ... " -NoNewline;
Write-Host "MAYBE" -ForegroundColor Green;