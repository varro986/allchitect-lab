. 'scripts/01. Load modules.ps1'
. 'scripts/02. Load data.ps1'

### Loading Azure subscription
Write-Host "Loading Azure subscription $subscription_Name ... " -NoNewline;
Write-Host "STARTED" -ForegroundColor Yellow;
Try
{
	Select-AzureSubscription –SubscriptionName $subscription_Name

    Write-Host "Loading Azure subscription $subscription_Name ... " -NoNewline;
	Write-Host "DONE" -ForegroundColor Green;
}
Catch [Exception]
{
    Write-Host "Loading Azure subscription $subscription_Name ... " -NoNewline;
	Write-Host "FAILED" -ForegroundColor Red;
    Write-Host "Error during 03. Create infrastructure execution" -ForegroundColor Red;
    Write-Host $_.Exception.Message -ForegroundColor Red;
	Break;
}

### Importing VMs
Write-Host "Importing VMs ... " -NoNewline;
Write-Host "STARTED" -ForegroundColor Yellow;
Try
{
	Write-Host "Importing VM $cloudservice_Name.$activeDirectory_Name ... ";
	Import-AzureVM -Path "$exportPath\$cloudservice_Name.$activeDirectory_Name.xml" | New-AzureVM -ServiceName $cloudservice_Name -VNetName $virtualNetwork_Name
	
	Write-Host "Importing VM $cloudservice_Name.$sqlServer_Name ... ";
	Import-AzureVM -Path "$exportPath\$cloudservice_Name.$sqlServer_Name.xml" | New-AzureVM -ServiceName $cloudservice_Name -VNetName $virtualNetwork_Name

	Write-Host "Importing VM $cloudservice_Name.$sharepoint_Name ... ";
	Import-AzureVM -Path "$exportPath\$cloudservice_Name.$sharepoint_Name.xml" | New-AzureVM -ServiceName $cloudservice_Name -VNetName $virtualNetwork_Name

    Write-Host "Importing VMs ... " -NoNewline;
	Write-Host "DONE" -ForegroundColor Green;
}
Catch [Exception]
{
    Write-Host "Importing VMs ... " -NoNewline;
	Write-Host "FAILED" -ForegroundColor Red;
    Write-Host $_.Exception.Message -ForegroundColor Red;
	Break;
}



### Starting VMs
Write-Host "Starting VMs ... " -NoNewline;
Write-Host "STARTED" -ForegroundColor Yellow;
Try
{
	Write-Host "Starting VM $cloudservice_Name.$activeDirectory_Name ... ";
	Start-AzureVM -ServiceName $cloudservice_Name -name $activeDirectory_Name
	
	Write-Host "Starting VM $cloudservice_Name.$sqlServer_Name ... ";
	Start-AzureVM -ServiceName $cloudservice_Name -name $sqlServer_Name

	Write-Host "Starting VM $cloudservice_Name.$sharepoint_Name ... ";
	Start-AzureVM -ServiceName $cloudservice_Name -name $sharepoint_Name

    Write-Host "Starting VMs ... " -NoNewline;
	Write-Host "DONE" -ForegroundColor Green;
}
Catch [Exception]
{
    Write-Host "Starting VMs ... " -NoNewline;
	Write-Host "FAILED" -ForegroundColor Red;
    Write-Host $_.Exception.Message -ForegroundColor Red;
	Break;
}


Write-Host "Everything done succesfully ... " -NoNewline;
Write-Host "MAYBE" -ForegroundColor Green;