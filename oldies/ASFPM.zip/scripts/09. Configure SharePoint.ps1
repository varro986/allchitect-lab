### Waiting
Write-Host "Waiting AD to boot ... "
WaitForBoot -serviceName $cloudService_Name -vmName $activeDirectory_Name;
Write-Host "Waiting SQL to boot ... "
WaitForBoot -serviceName $cloudService_Name -vmName $sqlServer_Name;
Write-Host "Waiting SharePoint to boot ... "
WaitForBoot -serviceName $cloudService_Name -vmName $sharepoint_Name;



### Connection credentials
$remoteSession_Username = "$domain_NetBiosName\$administrator_Username";
$credential = GetCredential -username $remoteSession_Username -password $administrator_Password;
$uris = Get-AzureWinRMUri -ServiceName $cloudservice_Name -Name $sharepoint_Name;



### SharePoint server VM basic configuration
Write-Host "Basic setup for SharePoint server VM ... " -NoNewline
Write-Host "STARTED" -ForegroundColor Yellow;

$returnValue = Invoke-Command -ComputerName $uris[0].DnsSafeHost -Credential $credential -Port $uris[0].Port -UseSSL -SessionOption (New-PSSessionOption -SkipCACheck -SkipCNCheck) -ScriptBlock $basicConfiguration;

If ($returnValue -eq 1)
{
	Write-Host "Basic setup for SharePoint server VM ... " -NoNewline
    Write-Host "DONE" -ForegroundColor Green;
}
Else
{
	Write-Host "Basic setup for SharePoint server VM ... " -NoNewline
	Write-Host "FAILED" -ForegroundColor Red;
    Write-Host "Error during 09. Configure SharePoint" -ForegroundColor Red;
	Break;
}

	

### SharePoint CredSSP configuration
Write-Host "Enabling CredSSP for SharePoint server VM (avoiding double hop issue) ... " -NoNewline
Write-Host "STARTED" -ForegroundColor Yellow;

Invoke-Command -ComputerName $uris[0].DnsSafeHost -Credential $credential -Port $uris[0].Port -UseSSL -SessionOption (New-PSSessionOption -SkipCACheck -SkipCNCheck) -ScriptBlock {
    param($administrator_Username, $administrator_Password, $sqlServer_IP)

	$is2012 = [Environment]::OSVersion.Version -ge (new-object 'Version' 6,2,9200,0)
	if($is2012)
	{
		$line = winrm g winrm/config/service/auth | Where-Object {$_.Contains('CredSSP = true')}
		$isCredSSPServerEnabled = -not [string]::IsNullOrEmpty($line)
		if(-not $isCredSSPServerEnabled)
		{
			Write-Host "Enabling CredSSP Server..."
			winrm s winrm/config/service/auth '@{CredSSP="true"}'
			Write-Host "CredSSP Server is enabled."
			
			Enable-PsRemoting;
			Enable-WSmanCredSSP -Role Client -DelegateComputer $sqlServer_IP -Force;
		}
		else
		{
			Write-Host "CredSSP Server is already enabled."
		}
	}
	else
	{
		schtasks /CREATE /TN "EnableCredSSP" /SC ONCE /SD 01/01/2020 /ST 00:00:00 /RL HIGHEST /RU $administrator_Username /RP $administrator_Password /TR "winrm set winrm/config/service/auth @{CredSSP=\""True\""}" /F
		schtasks /RUN /I /TN "EnableCredSSP"
		
		Enable-PsRemoting;
		Enable-WSmanCredSSP -Role Client -DelegateComputer $sqlServer_IP -Force;
	}
} -ArgumentList $administrator_Username, $administrator_Password, $sqlServer_IP;



### SharePoint server configuration
Write-Host "Configuring SharePoint farm ... " -NoNewline
Write-Host "STARTED" -ForegroundColor Yellow;

$returnValue = Invoke-Command -ComputerName $uris[0].DnsSafeHost -Credential $credential -Authentication Credssp -Port $uris[0].Port -UseSSL -SessionOption (New-PSSessionOption -SkipCACheck -SkipCNCheck) -ScriptBlock {
	param ($sqlServer_IP, $administrator_Password, $domain_NetBiosName, $sharepoint_CentralAdmin_Port)

    $v = 0;
    Try
    {
	    Set-ExecutionPolicy RemoteSigned
	    Set-ExecutionPolicy Unrestricted –force 

	    # Loopback check disabled
	    Write-Host "Disabling loopback check ... " -NoNewline;
	    Write-Host "STARTED";

	    $regVal = Get-ItemProperty -Path HKLM:\System\CurrentControlSet\Control\Lsa -Name "DisableLoopbackCheck"
			
	    if ($regVal -eq $null)
	    {
			Write-Host "Creating DisableLoopbackCheck registry key ... " -NoNewline;
			New-ItemProperty HKLM:\System\CurrentControlSet\Control\Lsa -Name "DisableLoopbackCheck" -value "1" -PropertyType dword
			Write-Host "DONE";
		}
	    else
	    {
			if($regVal.DisableLoopbackCheck -ne 1)
			{
				Write-Host "Editing DisableLoopbackCheck registry key ... " -NoNewline;
				Set-ItemProperty -Path HKLM:\System\CurrentControlSet\Control\Lsa -Name "DisableLoopbackCheck" -value "1"
				Write-Host "DONE";
			}
			Else
			{
				Write-Host "DisableLoopbackCheck registry key is OK, no action required"
			}
		}
		
	    Write-Host "Disabling loopback check ... " -NoNewline;
	    Write-Host "DONE";

	    Add-PSSnapin Microsoft.SharePoint.PowerShell

	    $spfarm = $null;
		
		Try
		{
			$spfarm = Get-SPFarm -ErrorAction SilentlyContinue;
		}
		Catch {}

	    If ($spfarm -eq $null)
	    {
			# Create or connect to database and farm
			Write-Host "Creating SharePoint configuration database ... STARTED";
			
			New-SPConfigurationDatabase -DatabaseName "SharePoint_Config" -AdministrationContentDatabaseName "SharePoint_Admin" -DatabaseServer $sqlServer_IP -Passphrase (ConvertTo-SecureString $administrator_Password -AsPlainText -Force) -FarmCredentials (New-Object System.Management.Automation.PSCredential "$domain_NetBiosName\spfarm", (ConvertTo-SecureString $administrator_Password -AsPlainText -Force)) -Verbose;
			Write-Host "Creating SharePoint configuration database ... DONE";
			
			Write-Host "SPHelpCollection installation ... " -NoNewLine;
			Install-SPHelpCollection -All
			Write-Host "DONE";
			
			Write-Host "SPResourceSecurity initialization ... " -NoNewLine;
			Initialize-SPResourceSecurity
			Write-Host "DONE";
			
			Write-Host "SPService installation ... " -NoNewLine;
			Install-SPService
			Write-Host "DONE";
			
			Install-SPFeature -AllExistingFeatures
			Write-Host "SPFeatures installation ... " -NoNewLine;
			Write-Host "DONE";

			Write-Host "Creating Central admin ... " -NoNewLine;
			New-SPCentralAdministration -Port $sharepoint_CentralAdmin_Port
			Write-Host "DONE";
			
			Write-Host "SPApplicationContent installation ... " -NoNewLine;
			Install-SPApplicationContent
			Write-Host "DONE";
		}
		Else
		{
			Write-Host "This server is already in a SharePoint farm."
		}

		$v = 1;
    }
    Catch [Exception]   
    {
        $v = 0;
		Write-Host $_.Exception.Message -ForegroundColor Red;;
    }

    return $v;
} -ArgumentList $sqlServer_IP, $administrator_Password, $domain_NetBiosName, $sharepoint_CentralAdmin_Port;
	
If ($returnValue -eq 1)
{
	Write-Host "Configuring SharePoint farm ... " -NoNewline
	Write-Host "DONE" -ForegroundColor Green;
}
Else
{
	Write-Host "Configuring SharePoint farm ... " -NoNewline
	Write-Host "FAILED" -ForegroundColor Red;
    Write-Host "Error during 09. Configure SharePoint" -ForegroundColor Red;
	Break;
}