### Waiting
Write-Host "Waiting AD to boot ... "
WaitForBoot -serviceName $cloudService_Name -vmName $activeDirectory_Name;



### Connection credentials
$remoteSession_Username = "\" + $activeDirectory_LocalAdministrator_Username;
$credential = GetCredential -username $remoteSession_Username -password $activeDirectory_LocalAdministrator_Password;
$uris = Get-AzureWinRMUri -ServiceName $cloudservice_Name -Name $activeDirectory_Name;



### Active directory VM basic configuration
Write-Host "Basic setup for Active directory VM ... " -NoNewline
Write-Host "STARTED" -ForegroundColor Yellow;

$returnValue = Invoke-Command -ComputerName $uris[0].DnsSafeHost -Credential $credential -Port $uris[0].Port -UseSSL -SessionOption (New-PSSessionOption -SkipCACheck -SkipCNCheck) -ScriptBlock $basicConfiguration;

If ($returnValue -eq 1)
{
	Write-Host "Basic setup for Active directory VM ... " -NoNewline
	Write-Host "DONE" -ForegroundColor Green;
}
Else
{
	Write-Host "Basic setup for Active directory VM ... " -NoNewline
	Write-Host "FAILED" -ForegroundColor Red;
    Write-Host "Error during 05. Configure Active directory" -ForegroundColor Red;
	Break;
}



### Active directory VM ADDS configuration
Write-Host "ADDS setup for Active directory VM ... " -NoNewline;
Write-Host "STARTED" -ForegroundColor Yellow;

$returnValue = Invoke-Command -ComputerName $uris[0].DnsSafeHost -Credential $credential -Port $uris[0].Port -UseSSL -SessionOption (New-PSSessionOption -SkipCACheck -SkipCNCheck) -ScriptBlock {
	param($domain_DomainName,$domain_NetBiosName,$activeDirectory_Name,$administrator_Password)
	
	$v = 0;
	Try
	{
		Add-WindowsFeature -Name "ad-domain-services" -IncludeAllSubFeature -IncludeManagementTools
		Add-WindowsFeature -Name "dns" -IncludeAllSubFeature -IncludeManagementTools
		Add-WindowsFeature -Name "gpmc" -IncludeAllSubFeature -IncludeManagementTools

		Import-Module ADDSDeployment

		$wmi = Get-WmiObject -Class Win32_ComputerSystem -ComputerName $activeDirectory_Name
		If ($wmi.Domain -eq $domain_DomainName)
		{
			Write-Host "Already joined to $domain_DomainName"
		}
		Else
		{
			$pwd = ConvertTo-SecureString -String $administrator_Password -AsPlainText -Force 
			#Install-ADDSForest -InstallDns:$true -DomainMode "Win2012" -ForestMode "Win2012" -DomainName $domain_DomainName -DomainNetbiosName $domain_NetBiosName -DatabasePath "C:\Windows\NTDS" -LogPath "C:\Windows\NTDS" -SysvolPath "C:\Windows\SYSVOL" -Force:$true -SafeModeAdministratorPassword $pwd
			
			Install-ADDSForest -CreateDnsDelegation:$false `
				-DatabasePath "C:\Windows\NTDS" `
				-DomainMode "Win2012" `
				-DomainName $domain_DomainName `
				-DomainNetbiosName $domain_NetBiosName `
				-ForestMode "Win2012" `
				-InstallDns:$true `
				-LogPath "C:\Windows\NTDS" `
				-NoRebootOnCompletion:$false `
				-SysvolPath "C:\Windows\SYSVOL" `
				-Force:$true -SafeModeAdministratorPassword $pwd
		}
		
		$v = 1;
	}
	Catch [Exception]   
	{ 
		$v = 0;
		Write-Host $_.Exception.Message -ForegroundColor Red;;
	}
	
	return $v;
} -ArgumentList $domain_DomainName,$domain_NetBiosName,$activeDirectory_Name,$administrator_Password;

If ($returnValue -eq 1)
{
	Write-Host "ADDS setup for Active directory VM ... " -NoNewline;
	Write-Host "DONE" -ForegroundColor Green;
}
Else
{
	Write-Host "ADDS setup for Active directory VM ... " -NoNewline;
	Write-Host "FAILED" -ForegroundColor Red;
    Write-Host "Error during 05. Configure Active directory" -ForegroundColor Red;
	Break;
}
    


### Wait reboot
Write-Host "Waiting AD to reboot ... "
Try
{
	Write-Host "Sleeping for 1 minute ... "
    Start-Sleep 60;
    WaitForBoot -serviceName $cloudService_Name -vmName $activeDirectory_Name;
} 
Catch [Exception]   
{
	Write-Host "FAILED" -ForegroundColor Red;
    Write-Host "Error during 05. Configure Active directory" -ForegroundColor Red;
    Write-Host $_.Exception.Message -ForegroundColor Red;
	Break;
}



### Active directory users config
Write-Host "Active directory users config ... " -NoNewline;
Write-Host "STARTED" -ForegroundColor Yellow;
$returnValue = Invoke-Command -ComputerName $uris[0].DnsSafeHost -Credential $credential -Port $uris[0].Port -UseSSL -SessionOption (New-PSSessionOption -SkipCACheck -SkipCNCheck) -ScriptBlock {
	param($domain_DomainName,$activeDirectory_Name,$administrator_Username,$administrator_Password)

	$v = 0;
	
	Try
	{	
		function CreateADUser([string]$loginName, [string]$name, [string]$surname, [string]$displayName, [string]$password, [string]$email)
		{
			$u = Get-ADUser -Filter {SamAccountName -eq $loginName}
			If($u -eq $null)
			{
				Write-Host "Creating $loginName AD user ... STARTED";
				$pwd = ConvertTo-SecureString -String $password -AsPlainText -Force;
				New-Aduser -UserPrincipalName $loginName -Name $loginName -SamAccountName $loginName -GivenName $name -Surname $surname -DisplayName $displayName -AccountPassword $pwd -EmailAddress $email -CannotChangePassword $true -PasswordNeverExpires $true -Enabled $true;
				Write-Host "Creating $loginName AD user ... DONE";
			}
			Else
			{
				Write-Host "$loginName AD user already exists";
			}
		}
		
		function AddADUserToADGroup([string]$loginName, [string]$groupName)
		{
			$m = Get-ADPrincipalGroupMembership $loginName | where-object {$_.name -eq $groupName} -ErrorAction SilentlyContinue; 
			If ($m -eq $null)
			{
				Write-Host "Adding $loginName to $groupName ... STARTED";
				$g = Get-AdGroup -filter {name -eq $groupName};
				Add-ADGroupMember $g.DistinguishedName $loginName;
				Write-Host "Adding $loginName to $groupName ... DONE";
			}
			Else
			{
				Write-Host "$loginName already belongs to $groupName";
			}
		}
		
		$wmi = Get-WmiObject -Class Win32_ComputerSystem -ComputerName $activeDirectory_Name
		If ($wmi.Domain -eq $domain_DomainName)
		{
			CreateADUser -loginName $administrator_Username -name "" -surname "" -displayName $administrator_Username -password $administrator_Password -email "administrator@farm.com" 
			
			$spfarm_Username = "SPFarm";
			CreateADUser -loginName $spfarm_Username -name "" -surname "" -displayName $spfarm_Username -password $administrator_Password -email "spfarm@farm.com" 
			
			$spserviceapp_Username = "SPServiceApp";
			CreateADUser -loginName $spserviceapp_Username -name "" -surname "" -displayName $spserviceapp_Username -password $administrator_Password -email "spserviceapp@farm.com" 

			$groupName = "Administrators";
			AddADUserToADGroup -loginName $administrator_Username -groupName $groupName;
			AddADUserToADGroup -loginName $spfarm_Username -groupName $groupName;
			AddADUserToADGroup -loginName $spserviceapp_Username -groupName $groupName;

			$groupName = "Domain Admins";
			AddADUserToADGroup -loginName $administrator_Username -groupName $groupName;
			AddADUserToADGroup -loginName $spfarm_Username -groupName $groupName;
			AddADUserToADGroup -loginName $spserviceapp_Username -groupName $groupName;
		
			$groupName = "Domain Users";
			AddADUserToADGroup -loginName $administrator_Username -groupName $groupName;
			AddADUserToADGroup -loginName $spfarm_Username -groupName $groupName;
			AddADUserToADGroup -loginName $spserviceapp_Username -groupName $groupName;
		
			$groupName = "Enterprise Admins";
			AddADUserToADGroup -loginName $administrator_Username -groupName $groupName;
			AddADUserToADGroup -loginName $spfarm_Username -groupName $groupName;
			AddADUserToADGroup -loginName $spserviceapp_Username -groupName $groupName;
			
			$groupName = "Group Policy Creator Owners";
			AddADUserToADGroup -loginName $administrator_Username -groupName $groupName;
			AddADUserToADGroup -loginName $spfarm_Username -groupName $groupName;
			AddADUserToADGroup -loginName $spserviceapp_Username -groupName $groupName;

			$groupName = "Performance Log Users";
			AddADUserToADGroup -loginName $administrator_Username -groupName $groupName;
			AddADUserToADGroup -loginName $spfarm_Username -groupName $groupName;
			AddADUserToADGroup -loginName $spserviceapp_Username -groupName $groupName;

			$groupName = "Schema Admins";
			AddADUserToADGroup -loginName $administrator_Username -groupName $groupName;
			AddADUserToADGroup -loginName $spfarm_Username -groupName $groupName;
			AddADUserToADGroup -loginName $spserviceapp_Username -groupName $groupName;
		}	
	    $v = 1;
    }
	Catch [Exception]   
	{ 
		$v = 0;
		Write-Host $_.Exception.Message -ForegroundColor Red;
	}
	
	return $v;
	
} -ArgumentList $domain_DomainName,$activeDirectory_Name,$administrator_Username,$administrator_Password;

If ($returnValue -eq 1)
{
	Write-Host "Active directory users config ... " -NoNewline;
    Write-Host "DONE" -ForegroundColor Green;
}
else
{
    Write-Host "Active directory users config ... " -NoNewline;
	Write-Host "FAILED" -ForegroundColor Red;
    Write-Host "Error during 05. Configure Active directory" -ForegroundColor Red;
    break;
} 