### Waiting
Write-Host "Waiting AD to boot ... "
WaitForBoot -serviceName $cloudService_Name -vmName $activeDirectory_Name;
Write-Host "Waiting SQL to boot ... "
WaitForBoot -serviceName $cloudService_Name -vmName $sqlServer_Name;



### Connection credentials
$remoteSession_Username = "\" + $sqlServer_LocalAdministrator_Username;
$credential = GetCredential -username $remoteSession_Username -password $sqlServer_LocalAdministrator_Password;
$uris = Get-AzureWinRMUri -ServiceName $cloudservice_Name -Name $sqlServer_Name;



### SQL server VM basic configuration
Write-Host "Basic setup for SQL server VM ... " -NoNewline
Write-Host "STARTED" -ForegroundColor Yellow;

$returnValue = Invoke-Command -ComputerName $uris[0].DnsSafeHost -Credential $credential -Port $uris[0].Port -UseSSL -SessionOption (New-PSSessionOption -SkipCACheck -SkipCNCheck) -ScriptBlock $basicConfiguration;

If ($returnValue -eq 1)
{
	Write-Host "Basic setup for SQL server VM ... " -NoNewline
    Write-Host "DONE" -ForegroundColor Green;
}
Else
{
	Write-Host "Basic setup for SQL server VM ... " -NoNewline
	Write-Host "FAILED" -ForegroundColor Red;
    Write-Host "Error during 07. Configure SQL server" -ForegroundColor Red;
	Break;
}



### SQL server configuration
Write-Host "SQL server DBMS setup ... " -NoNewline
Write-Host "STARTED" -ForegroundColor Yellow;

$returnValue = Invoke-Command -ComputerName $uris[0].DnsSafeHost -Credential $credential -Port $uris[0].Port -UseSSL -SessionOption (New-PSSessionOption -SkipCACheck -SkipCNCheck) -ScriptBlock {
	param($domain_DomainName,$domain_NetBiosName,$sqlServer_Name,$administrator_Username,$administrator_Password)
    
    $v = 0;
    Try
    {
        Set-ExecutionPolicy RemoteSigned
        Set-ExecutionPolicy Unrestricted –force 

        $wmi = Get-WmiObject -Class Win32_ComputerSystem -ComputerName $sqlServer_Name
        If ($wmi.Domain -eq $domain_DomainName)
        {
            [System.Reflection.Assembly]::LoadWithPartialName("Microsoft.SqlServer.SqlWmiManagement") | out-null
		    $dbmsSettings = New-Object ('Microsoft.SqlServer.Management.Smo.Wmi.ManagedComputer')
		    $sqlName = $dbmsSettings.Name;
		    $sqlInstance = $dbmsSettings.ServerInstances.Name;
		    $urn = "ManagedComputer[@Name='$sqlName']/ServerInstance[@Name='$sqlInstance']/ServerProtocol[@Name='Tcp']"
		    $tcp = $dbmsSettings.GetSmoObject($urn)
		
		    if (!$tcp.IsEnabled)
		    {
			    $tcp.IsEnabled = $true    
			    Write-Host "TCP enabled"
		    }
		    Else
		    {
			    Write-Host "TCP already enabled"
		    }
		
			Write-Host "Sleeping for 1 minute ... "
			Start-Sleep 60;
		
		    $domainAdministrator = "$domain_NetBiosName\$administrator_Username"
		    $domainSPFarm = "$domain_NetBiosName\spfarm"

			Write-Host "SQL server permissions setup ... " -NoNewline
			Write-Host "STARTED";

		    Import-Module "sqlps" -DisableNameChecking
		    Invoke-Sqlcmd -ServerInstance $sqlServer_Name -Database master -Query `
		    "	    
            USE [master]
        
            IF Not EXISTS (SELECT name FROM master.sys.server_principals WHERE name = '$domainAdministrator')
            BEGIN
		        CREATE LOGIN [$domainAdministrator] FROM WINDOWS
                EXEC sp_addsrvrolemember '$domainAdministrator', 'dbcreator'
			    EXEC sp_addsrvrolemember '$domainAdministrator', 'securityadmin'
		        EXEC sp_addsrvrolemember '$domainAdministrator', 'sysadmin'
            END      
		
		    IF Not EXISTS (SELECT name FROM master.sys.server_principals WHERE name = '$domainSPFarm')
            BEGIN
		        CREATE LOGIN [$domainSPFarm] FROM WINDOWS
                EXEC sp_addsrvrolemember '$domainSPFarm', 'dbcreator'
			    EXEC sp_addsrvrolemember '$domainSPFarm', 'securityadmin'
		        EXEC sp_addsrvrolemember '$domainSPFarm', 'sysadmin'
            END      
            EXEC sp_addsrvrolemember 'NT AUTHORITY\SYSTEM', 'sysadmin'
            "
		    Write-Host "Admin and SPFarm account added to SQL sysadmin group"
			
			Write-Host "SQL server permissions setup ... " -NoNewline
			Write-Host "DONE"
        }

        $v = 1;
    }
    Catch [Exception]   
	{ 
		$v = 0;
		Write-Host $_.Exception.Message;
	}

    return $v;

} -ArgumentList $domain_DomainName,$domain_NetBiosName,$sqlServer_Name,$administrator_Username,$administrator_Password

If ($returnValue -eq 1)
{
	Write-Host "SQL server DBMS setup ... " -NoNewline
	Write-Host "DONE" -ForegroundColor Green;
}
Else
{
	Write-Host "SQL server DBMS setup ... " -NoNewline
	Write-Host "FAILED" -ForegroundColor Red;
    Write-Host "Error during 07. Configure SQL server" -ForegroundColor Red;
	Break;
}