Write-Host "Stopping AD ... " -NoNewline
Stop-AzureVM -ServiceName $cloudService_Name -Name $activeDirectory_Name;



Write-Host "Stopping SQL ... " -NoNewline
Stop-AzureVM -ServiceName $cloudService_Name -Name $sqlServer_Name;



Write-Host "Stopping SharePoint ... " -NoNewline
Stop-AzureVM -ServiceName $cloudService_Name -Name $sharepoint_Name;