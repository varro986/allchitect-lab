## Creating SharePoint VM
Write-Host "Creating virtual machine $sharepoint_Name ... " -NoNewline
Write-Host "STARTED" -ForegroundColor Yellow;
Try
{
    $vm = Get-AzureVM -ServiceName $cloudService_Name -Name $sharepoint_Name;
	If ($vm -eq $null)
	{	
	    $image = GetAzureLatestImage -imageLabel $sharepoint_ImageLabel;
	    CreateAzureVM -vm_Name $sharepoint_Name -vm_Size $sharepoint_Size -vm_Image $image -vNet $virtualNetwork_Name -subnet_Name $subnet_Name -admin_Username $sharepoint_LocalAdministrator_Username -admin_Password $sharepoint_LocalAdministrator_Password, -cloudservice_Name $cloudservice_Name -affinityGroup_Name $affinityGroup_Name -domain_Name $domain_DomainName -domain_NetBiosName $domain_NetBiosName -domainAdmin_Name $administrator_Username -domainAdmin_Password $administrator_Password -vm_Ip $sharepoint_IP
        Write-Host "Creating virtual machine $sharepoint_Name ... " -NoNewline	    
        Write-Host "DONE" -ForegroundColor Green;
		
		Write-Host "Sleeping for 1 minute ... "
		Start-Sleep 60;
    }
    Else
	{
        Write-Host "Creating virtual machine $sharepoint_Name ... " -NoNewline
		Write-Host "LOADED PREEXISTING ONE" -ForegroundColor Yellow;
	}
}
Catch [Exception]
{
    Write-Host "Creating virtual machine $sharepoint_Name ... " -NoNewline
    Write-Host "FAILED" -ForegroundColor Red;
    Write-Host "Error during 08. Create SharePoint VM" -ForegroundColor Red;
    Write-Host $_.Exception.Message -ForegroundColor Red;
	Break;
}