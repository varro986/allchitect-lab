### Connection credentials
$remoteSession_Username = "$domain_NetBiosName\$administrator_Username";
$credential = GetCredential -username $remoteSession_Username -password $administrator_Password;
$uris = Get-AzureWinRMUri -ServiceName $cloudservice_Name -Name $sharepoint_Name;
$spfarm_Username = "SPFarm";
$farmAccount = "$domain_NetBiosName\$spfarm_Username";
$spserviceapp_Username = "SPServiceApp";
$serviceAppAccount = "$domain_NetBiosName\$spserviceapp_Username";



### SharePoint managed account configuration
Write-Host "Configuring SharePoint managed accounts ... " -NoNewline
Write-Host "STARTED" -ForegroundColor Yellow;
$returnValue = Invoke-Command -ComputerName $uris[0].DnsSafeHost -Credential $credential -Authentication Credssp -Port $uris[0].Port -UseSSL -SessionOption (New-PSSessionOption -SkipCACheck -SkipCNCheck) -ScriptBlock {
	param ($farmAccount, $serviceAppAccount, $administrator_Password)
    $v = 0;
    Try
    {
	    Set-ExecutionPolicy RemoteSigned
	    Set-ExecutionPolicy Unrestricted –force 

	    Add-PSSnapin Microsoft.SharePoint.PowerShell
   
		function CreateSPManagedAccount([string]$loginName,[string]$password)
		{
			$a = Get-SPManagedAccount $loginName -ErrorAction SilentlyContinue;
			If ($a -eq $null)
			{
				Write-Host "Creating SPManagedAccount $loginName ... STARTED";
				$p = ConvertTo-SecureString -String $password -AsPlainText -Force;
				$c = New-Object -TypeName System.Management.Automation.PSCredential -ArgumentList $loginName,$p;
				New-SPManagedAccount -Credential $c;
				Write-Host "Creating SPManagedAccount $loginName ... DONE";
			}
			Else
			{
				Write-Host "SPManagedAccount $loginName already exists";
			}
		}
   
		$spfarm = Get-SPFarm -ErrorAction SilentlyContinue;
		
	    If ($spfarm -ne $null)
	    {
			CreateSPManagedAccount -loginName $farmAccount -password $administrator_Password;
			CreateSPManagedAccount -loginName $serviceAppAccount -password $administrator_Password;
			
			$v = 1;
		}
	    Else
	    {
			Write-Host "No SharePoint farm, cannot proceed with installation";
			$v = 0;
		}
    }
    Catch [Exception]
    {
		Write-Host $_.Exception.Message -ForegroundColor Red;
        $v = 0;
    }

    return $v;
} -ArgumentList $farmAccount, $serviceAppAccount, $administrator_Password;
	
If ($returnValue -eq 1)
{
	Write-Host "Configuring SharePoint managed accounts ... " -NoNewline
	Write-Host "DONE" -ForegroundColor Green;
}
Else
{
	Write-Host "Configuring SharePoint managed accounts ... " -NoNewline
	Write-Host "FAILED" -ForegroundColor Red;
    Write-Host "Error during 10. Configure SharePoint Service App" -ForegroundColor Red;
	Break;
}



### User profile configuration
Write-Host "Configuring User Profile Service Application ... " -NoNewline
Write-Host "STARTED" -ForegroundColor Yellow;

$returnValue = Invoke-Command -ComputerName $uris[0].DnsSafeHost -Credential $credential -Authentication Credssp -Port $uris[0].Port -UseSSL -SessionOption (New-PSSessionOption -SkipCACheck -SkipCNCheck) -ScriptBlock {
	param ($farmAccount, $serviceAppAccount)

    $v = 0;
    Try
    {
	    Set-ExecutionPolicy RemoteSigned
	    Set-ExecutionPolicy Unrestricted –force 

	    Add-PSSnapin Microsoft.SharePoint.PowerShell
   
		$spfarm = Get-SPFarm -ErrorAction SilentlyContinue;
		
	    If ($spfarm -ne $null)
	    {
            # Creating Managed metadata application pool
            $serviceAppPool_Name = "User Profile Application Pool";
            $serviceAppPool = Get-SPServiceApplicationPool $serviceAppPool_Name -ErrorAction SilentlyContinue;
            If ($serviceAppPool -eq $null)
            {
                Write-Host "Creating $serviceAppPool_Name ... STARTED";
                $serviceAppPool = New-SPServiceApplicationPool -Name $serviceAppPool_Name -Account (Get-SPManagedAccount $farmAccount);
                Write-Host "Creating $serviceAppPool_Name ... DONE";
            }
            Else
            {
                Write-Host "$serviceAppPool_Name already exists";
            }

			# User profile service application
            $userProfileServiceName = "User Profile Service Application";
			$upa = Get-SPServiceApplication | where-object {$_.DisplayName -eq $userProfileServiceName };
			If ($upa -eq $null)
			{
				$userProfileDB = "SharePoint_UserProfile"; 
				$userProfileSyncDB = "SharePoint_UserProfile_Sync"; 
				$userProfileSocialDB = "SharePoint_UserProfile_Social";
											
				Write-Host "Creating $userProfileServiceName ... STARTED";
				$upa = New-SPProfileServiceApplication -Name $userProfileServiceName -ApplicationPool $serviceAppPool -ProfileDBName  $userProfileDB -SocialDBName $userProfileSocialDB -ProfileSyncDBName $userProfileSyncDB;
				Write-Host "Creating $userProfileServiceName ... DONE";
			}
			Else
			{
				Write-Host "$userProfileServiceName already exists";
			}
			
			# User profile service application proxy
			$userProfileServiceAppProxy = "User Profile Service Application Proxy";
			$upaProxy = Get-SPServiceApplicationProxy | where-object {$_.DisplayName -eq $userProfileServiceAppProxy};
			if ($upaProxy -eq $null)
			{
				Write-Host "Creating $userProfileServiceAppProxy ... STARTED";
				$upaProxy = New-SPProfileServiceApplicationProxy -Name $userProfileServiceAppProxy -ServiceApplication $upa -DefaultProxyGroup;
				Write-Host "Creating $userProfileServiceAppProxy ... DONE";
			}
			else
			{
				Write-Host "$userProfileServiceAppProxy already exists";
			}
			
			# Start the user profile service 
			$service = Get-SPServiceInstance | where {$_.TypeName -eq "User Profile Service"}
			if ($service.Status -ne "Online") {
				Write-Host "Starting User Profile Service instance" -NoNewline
				$service | Start-SPServiceInstance | Out-Null
				while ($true) 
				{
					Start-Sleep 10
					$svc = Get-SPServiceInstance | where {$_.TypeName -eq "User Profile Service"}
					if ($svc.Status -eq "Online") 
					{ 
						break; 
					}
				}
			}
			
			$v = 1;
		}
	    Else
	    {
			Write-Host "No SharePoint farm, cannot proceed with installation";
			$v = 0;
		}
    }
    Catch [Exception]
    {
		Write-Host $_.Exception.Message -ForegroundColor Red;
        $v = 0;
    }

    return $v;
} -ArgumentList $farmAccount, $serviceAppAccount;
	
If ($returnValue -eq 1)
{
	Write-Host "Configuring User Profile Service Application ... " -NoNewline
	Write-Host "DONE" -ForegroundColor Green;
}
Else
{
	Write-Host "Configuring User Profile Service Application ... " -NoNewline
	Write-Host "FAILED" -ForegroundColor Red;
    Write-Host "Error during 10. Configure SharePoint Service App" -ForegroundColor Red;
	Break;
}



### Managed metadata configuration
Write-Host "Configuring Managed metadata Service Application ... " -NoNewline
Write-Host "STARTED" -ForegroundColor Yellow;

$returnValue = Invoke-Command -ComputerName $uris[0].DnsSafeHost -Credential $credential -Authentication Credssp -Port $uris[0].Port -UseSSL -SessionOption (New-PSSessionOption -SkipCACheck -SkipCNCheck) -ScriptBlock {
	param ($farmAccount, $serviceAppAccount)

    $v = 0;
    Try
    {
	    Set-ExecutionPolicy RemoteSigned
	    Set-ExecutionPolicy Unrestricted –force 

	    Add-PSSnapin Microsoft.SharePoint.PowerShell
   
		$spfarm = Get-SPFarm -ErrorAction SilentlyContinue;
		
	    If ($spfarm -ne $null)
	    {
            # Creating Managed metadata application pool
            $serviceAppPool_Name = "Managed Metadata Application Pool";
            $serviceAppPool = Get-SPServiceApplicationPool $serviceAppPool_Name -ErrorAction SilentlyContinue;
            If ($serviceAppPool -eq $null)
            {
                Write-Host "Creating $serviceAppPool_Name ... STARTED";
                $serviceAppPool = New-SPServiceApplicationPool -Name $serviceAppPool_Name -Account (Get-SPManagedAccount $serviceAppAccount);
                Write-Host "Creating $serviceAppPool_Name ... DONE";
            }
            Else
            {
                Write-Host "$serviceAppPool_Name already exists";
            }

            # Creating Managed metadata service application
			$managedMetadataServiceName = "Managed Metadata Service Application";
			$mma = Get-SPServiceApplication | where-object {$_.DisplayName -eq $managedMetadataServiceName }
            if ($mma -eq $null)
            {
				$managedMetadataDB = "SharePoint_ManagedMetadata";
				
				Write-Host "Creating $managedMetadataServiceName ... STARTED";
                $mma = New-SPMetadataServiceApplication -Name $managedMetadataServiceName -ApplicationPool $serviceAppPool -DatabaseName $managedMetadataDB;
				Write-Host "Creating $managedMetadataServiceName ... DONE";
			}
			else
            {
                Write-Host "$managedMetadataServiceName already exists";
            }
			
			# Creating Managed metadata service application proxy
			$managedMetadataServiceAppProxy = "Managed Metadata Service Application Proxy";
			$mmaProxy = Get-SPMetadataServiceApplicationProxy -Identity $managedMetadataServiceAppProxy;
			if ($mmaProxy -eq $null)
			{
				Write-Host "Creating $managedMetadataServiceAppProxy ... STARTED";
                $mmaProxy = New-SPMetadataServiceApplicationProxy -Name $managedMetadataServiceAppProxy -ServiceApplication $mma -DefaultProxyGroup;
                $mmaProxy.Properties["IsDefaultKeywordTaxonomy"] = $false
                $mmaProxy.Properties["IsDefaultSiteCollectionTaxonomy"] = $false
                $mmaProxy.Properties["IsNPContentTypeSyndicationEnabled"] = $false
                $mmaProxy.Properties["IsContentTypePushdownEnabled"] = $false
                $mmaProxy.Update()
				Write-Host "Creating $managedMetadataServiceAppProxy ... DONE";
			}
			else
			{
				Write-Host "$managedMetadataServiceAppProxy already exists";
			}
			
			# Restarting Managed metadata service application
			$mmaSvc = (Get-SPServiceInstance | ?{$_.TypeName -eq "Managed Metadata Web Service"} );
			If ($mmaSvc.Status -eq "Disabled")
			{
				Write-Host "Restarting Managed Metadata Web Service ... STARTED";
				$mmaSvc | Start-SPServiceInstance;
				Write-Host "Restarting Managed Metadata Web Service ... DONE";
			}
            Else
            {
                Write-Host "Managed Metadata Web Service already online";
            }
			
			$v = 1;
		}
	    Else
	    {
			Write-Host "No SharePoint farm, cannot proceed with installation";
			$v = 0;
		}
    }
    Catch [Exception]
    {
		Write-Host $_.Exception.Message -ForegroundColor Red;
        $v = 0;
    }

    return $v;
} -ArgumentList $farmAccount, $serviceAppAccount;
	
If ($returnValue -eq 1)
{
	Write-Host "Configuring Managed metadata Service Application ... " -NoNewline
	Write-Host "DONE" -ForegroundColor Green;
}
Else
{
	Write-Host "Configuring Managed metadata Service Application ... " -NoNewline
	Write-Host "FAILED" -ForegroundColor Red;
    Write-Host "Error during 10. Configure SharePoint Service App" -ForegroundColor Red;
	Break;
}



### Search service configuration
Write-Host "Configuring Search Service Application ... " -NoNewline
Write-Host "STARTED" -ForegroundColor Yellow;
$returnValue = Invoke-Command -ComputerName $uris[0].DnsSafeHost -Credential $credential -Authentication Credssp -Port $uris[0].Port -UseSSL -SessionOption (New-PSSessionOption -SkipCACheck -SkipCNCheck) -ScriptBlock {
	param ($farmAccount, $serviceAppAccount)

    $v = 0;
    Try
    {
	    Set-ExecutionPolicy RemoteSigned
	    Set-ExecutionPolicy Unrestricted –force 

	    Add-PSSnapin Microsoft.SharePoint.PowerShell
   
		$spfarm = Get-SPFarm -ErrorAction SilentlyContinue;
		
	    If ($spfarm -ne $null)
	    {
            # Creating Managed metadata application pool
            $serviceAppPool_Name = "Search Application Pool";
            $serviceAppPool = Get-SPServiceApplicationPool $serviceAppPool_Name -ErrorAction SilentlyContinue;
            If ($serviceAppPool -eq $null)
            {
                Write-Host "Creating $serviceAppPool_Name ... STARTED";
                $serviceAppPool = New-SPServiceApplicationPool -Name $serviceAppPool_Name -Account (Get-SPManagedAccount $serviceAppAccount);
                Write-Host "Creating $serviceAppPool_Name ... DONE";
            }
            Else
            {
                Write-Host "$serviceAppPool_Name already exists";
            }
            
			$searchServerName = (Get-ChildItem env:computername).value;
            Write-Host "Starting Search Service Instances...";
            Start-SPEnterpriseSearchServiceInstance $searchServerName;
            Start-SPEnterpriseSearchQueryAndSiteSettingsServiceInstance $searchServerName;
			
			$searchServiceName = "Search Service Application";
			$ssa = Get-SPEnterpriseSearchServiceApplication -Identity $searchServiceName -ErrorAction SilentlyContinue;
			If ($ssa -eq $null)
			{
				Write-Host "Creating $searchServiceName ... STARTED";
				$searchDB = "SharePoint_Search";
				$ssa = New-SPEnterpriseSearchServiceApplication -Partitioned -Name $searchServiceName -ApplicationPool $serviceAppPool -DatabaseName $searchDB 
				Write-Host "Creating $searchServiceName ... DONE";
			}
			Else
			{
				Write-Host "$searchServiceName already exists";
			}
			
			$searchServiceProxyName = "Search Service Application Proxy";
			$ssaProxy = Get-SPEnterpriseSearchServiceApplicationProxy -Identity $searchServiceProxyName -ErrorAction SilentlyContinue;
			If ($ssaProxy -eq $null)
			{
				Write-Host "Creating $searchServiceProxyName ... STARTED";
				$ssaProxy = New-SPEnterpriseSearchServiceApplicationProxy -Partitioned -Name $searchServiceProxyName -SearchApplication $ssa;
				Write-Host "Creating $searchServiceProxyName ... DONE";
			}
			Else
			{
			    Write-Host "$searchServiceProxyName already exists";
			}
			
			Write-Host "Initializing Search Admin component ... STARTED";
			$ssi = Get-SPEnterpriseSearchServiceInstance -local | Start-SPEnterpriseSearchServiceInstance;
			
			While ($ssi.Status -ne "Online") 
			{
				Start-Sleep -Seconds 10;
				$ssi = Get-SPEnterpriseSearchServiceInstance -local;
			}
			
			
			$ssi = Get-SPEnterpriseSearchServiceInstance;
			set-spenterprisesearchadministrationcomponent –searchapplication $ssa –searchserviceinstance $ssi -Force;
			$searchServiceAdmin = ($ssa | Get-SPEnterpriseSearchAdministrationComponent);

			While (-not $searchServiceAdmin.Initialized) 
			{
				Start-Sleep -Seconds 10;
				$searchServiceAdmin = $ssa | Get-SPEnterpriseSearchAdministrationComponent;
			}
			Write-Host "Initializing Search Admin component ... DONE";
	
			$activeTopology = $ssa.ActiveTopology;			
			If ($activeTopology.ComponentCount -eq 0)
			{
				Write-Host "Configuring Search Component Topology ... STARTED";
				$activeTopology = $activeTopology.Clone();
				New-SPEnterpriseSearchAdminComponent –SearchTopology $activeTopology -SearchServiceInstance $ssi;
				New-SPEnterpriseSearchContentProcessingComponent –SearchTopology $activeTopology -SearchServiceInstance $ssi; 
				New-SPEnterpriseSearchAnalyticsProcessingComponent –SearchTopology $activeTopology -SearchServiceInstance $ssi; 
				New-SPEnterpriseSearchCrawlComponent –SearchTopology $activeTopology -SearchServiceInstance $ssi; 
				New-SPEnterpriseSearchIndexComponent –SearchTopology $activeTopology -SearchServiceInstance $ssi;
				New-SPEnterpriseSearchQueryProcessingComponent –SearchTopology $activeTopology -SearchServiceInstance $ssi; 
				$activeTopology.Activate();
				Write-Host "Configuring Search Component Topology ... DONE";
			}
			Else
			{
				Write-Host "Search Component Topology already configured";
			}
		
			$v = 1;
		}
	    Else
	    {
			Write-Host "No SharePoint farm, cannot proceed with installation";
			$v = 0;
		}
    }
    Catch [Exception]
    {
		Write-Host $_.Exception.Message -ForegroundColor Red;
        $v = 0;
    }

    return $v;
} -ArgumentList $farmAccount, $serviceAppAccount;
	
If ($returnValue -eq 1)
{
	Write-Host "Configuring Search Service Application ... " -NoNewline
	Write-Host "DONE" -ForegroundColor Green;
}
Else
{
	Write-Host "Configuring Search Service Application ... " -NoNewline
	Write-Host "FAILED" -ForegroundColor Red;
    Write-Host "Error during 10. Configure SharePoint Service App" -ForegroundColor Red;
	Break;
}