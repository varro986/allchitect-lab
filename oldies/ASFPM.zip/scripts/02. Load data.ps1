### Ask environment
Write-Host "Enter config file name (e.g. DEV for DEV.xml) or press enter for Config.xml";
$env = Read-Host "Config file name"    
If ([string]::IsNullOrEmpty($env))
{
	$env = "Config";
}



### Loading XML data
Write-Host "Loading $env.XML data ... " -NoNewline;
Try
{
    $currentDir = [string](Get-Location);
	$exportPath = "$currentDir\export";
    [xml]$configXML = Get-Content "$currentDir\$env.xml";
	
    #Subscription
	$subscription_Name = RaiseExceptionIfNullOrEmpty($configXML.Config.Subscription);

    # Affinity group
    $affinityGroup_Name = RaiseExceptionIfNullOrEmpty($configXML.Config.AffinityGroup.Name);
    $affinityGroup_Location = RaiseExceptionIfNullOrEmpty($configXML.Config.AffinityGroup.Location);

    # Storage account
    $storageAccount_Name = RaiseExceptionIfNullOrEmpty($configXML.Config.StorageAccount.Name);

    #Virtual network
    $virtualNetwork_Name = RaiseExceptionIfNullOrEmpty($configXML.Config.VirtualNetwork.Name);
    $virtualNetwork_AddressPrefix = RaiseExceptionIfNullOrEmpty($configXML.Config.VirtualNetwork.AddressPrefix);
	
    #DNS
    $dns_Name = RaiseExceptionIfNullOrEmpty($configXML.Config.VirtualNetwork.Dns.Name);
    $dns_Ip = RaiseExceptionIfNullOrEmpty($configXML.Config.VirtualNetwork.Dns.Ip);

    #Subnet
    $subnet_Name = RaiseExceptionIfNullOrEmpty($configXML.Config.VirtualNetwork.Subnet.Name);
    $subnet_AddressPrefix = RaiseExceptionIfNullOrEmpty($configXML.Config.VirtualNetwork.Subnet.AddressPrefix);

	#Cloud service
	$cloudservice_Name = RaiseExceptionIfNullOrEmpty($configXML.Config.CloudService.Name);
	$cloudservice_HostName = $cloudservice_Name + ".cloudapp.net"
		
    #Domain
    $domain_DomainName = RaiseExceptionIfNullOrEmpty($configXML.Config.Domain.Name);
    $domain_NetBiosName = RaiseExceptionIfNullOrEmpty($configXML.Config.Domain.Netbios);

    #Administrator
    $administrator_Username = RaiseExceptionIfNullOrEmpty($configXML.Config.Domain.Administrator.Username);
    $administrator_Password = RaiseExceptionIfNullOrEmpty($configXML.Config.Domain.Administrator.Password);

    #Domain controller
	$activeDirectory_Name = RaiseExceptionIfNullOrEmpty($configXML.Config.VirtualMachines.ActiveDirectory.Name);
	$activeDirectory_Size = RaiseExceptionIfNullOrEmpty($configXML.Config.VirtualMachines.ActiveDirectory.Size);
	$activeDirectory_ImageLabel = RaiseExceptionIfNullOrEmpty($configXML.Config.VirtualMachines.ActiveDirectory.ImageLabel);
	$activeDirectory_LocalAdministrator_Username = RaiseExceptionIfNullOrEmpty($configXML.Config.VirtualMachines.ActiveDirectory.LocalAdministrator.Username);
	$activeDirectory_LocalAdministrator_Password = RaiseExceptionIfNullOrEmpty($configXML.Config.VirtualMachines.ActiveDirectory.LocalAdministrator.Password);
    $activeDirectory_IP = "10.0.0.4";
    
    #SQL server
	$sqlServer_Name = RaiseExceptionIfNullOrEmpty($configXML.Config.VirtualMachines.SQLServer.Name);
	$sqlServer_Size = RaiseExceptionIfNullOrEmpty($configXML.Config.VirtualMachines.SQLServer.Size);
	$sqlServer_ImageLabel = RaiseExceptionIfNullOrEmpty($configXML.Config.VirtualMachines.SQLServer.ImageLabel);
	$sqlServer_LocalAdministrator_Username = RaiseExceptionIfNullOrEmpty($configXML.Config.VirtualMachines.SQLServer.LocalAdministrator.Username);
	$sqlServer_LocalAdministrator_Password = RaiseExceptionIfNullOrEmpty($configXML.Config.VirtualMachines.SQLServer.LocalAdministrator.Password);
    $sqlServer_IP = "10.0.0.5";
	
    #SharePoint 2013 server
	$sharepoint_Name = RaiseExceptionIfNullOrEmpty($configXML.Config.VirtualMachines.SharePoint.Name);
	$sharepoint_Size = RaiseExceptionIfNullOrEmpty($configXML.Config.VirtualMachines.SharePoint.Size);
	$sharepoint_ImageLabel = RaiseExceptionIfNullOrEmpty($configXML.Config.VirtualMachines.SharePoint.ImageLabel);
	$sharepoint_LocalAdministrator_Username = RaiseExceptionIfNullOrEmpty($configXML.Config.VirtualMachines.SharePoint.LocalAdministrator.Username);
	$sharepoint_LocalAdministrator_Password = RaiseExceptionIfNullOrEmpty($configXML.Config.VirtualMachines.SharePoint.LocalAdministrator.Password);
    $sharepoint_IP = "10.0.0.6";
	$sharepoint_CentralAdmin_Port = RaiseExceptionIfNullOrEmpty($configXML.Config.VirtualMachines.SharePoint.CentralAdmin.Port);

    Write-Host "DONE" -ForegroundColor  Green;
}
Catch [Exception] 
{
    Write-Host "FAILED" -ForegroundColor Red;
    Write-Host "Error during 02. Load data execution" -ForegroundColor Red;
    Write-Host $_.Exception.Message -ForegroundColor Red;
	Break;
}