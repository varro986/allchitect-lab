Write-Host "Starting AD ... " -NoNewline
Try
{
	Start-AzureVM -ServiceName $cloudService_Name -Name $activeDirectory_Name;
	Write-Host "DONE" -ForegroundColor Green;
}
Catch [Exception]
{
	Write-Host "FAILED" -ForegroundColor Red;
    Write-Host $_.Exception.Message -ForegroundColor Red;
	Break;
}



Write-Host "Waiting AD to boot ... "
WaitForBoot -serviceName $cloudService_Name -vmName $activeDirectory_Name;



Write-Host "Starting SQL ... " -NoNewline
Try
{
	Start-AzureVM -ServiceName $cloudService_Name -Name $sqlServer_Name;
	Write-Host "DONE" -ForegroundColor Green;
}
Catch [Exception]
{
	Write-Host "FAILED" -ForegroundColor Red;
    Write-Host $_.Exception.Message -ForegroundColor Red;
	Break;
}



Write-Host "Waiting SQL to boot ... "
WaitForBoot -serviceName $cloudService_Name -vmName $sqlServer_Name;



Write-Host "Starting SharePoint ... " -NoNewline
Try
{
	Start-AzureVM -ServiceName $cloudService_Name -Name $sharepoint_Name;
	Write-Host "DONE" -ForegroundColor Green;
}
Catch [Exception]
{
	Write-Host "FAILED" -ForegroundColor Red;
    Write-Host $_.Exception.Message -ForegroundColor Red;
	Break;
}



Write-Host "Waiting SharePoint to boot ... "
WaitForBoot -serviceName $cloudService_Name -vmName $sharepoint_Name;



