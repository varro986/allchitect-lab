### Loading custom PowerShell modules
Write-Host "Loading custom PowerShell modules ... " -NoNewline
Try
{
    $currentDir = [string](Get-Location);
	Import-Module -Name ($currentDir + "\modules\CreateAzureVirtualNetwork.psm1");
	Import-Module -Name ($currentDir + "\modules\CreateAzureVM.psm1");
	Import-Module -Name ($currentDir + "\modules\EnableAutomaticUpdate.psm1");
	Import-Module -Name ($currentDir + "\modules\GetAzureLatestImage.psm1");
	Import-Module -Name ($currentDir + "\modules\GetCredential.psm1");
	Import-Module -Name ($currentDir + "\modules\StringHelper.psm1");
	Import-Module -Name ($currentDir + "\modules\WaitForBootAzureVM.psm1");
    Write-Host "DONE" -ForegroundColor Green;
}
Catch [Exception]   
{
	Write-Host "FAILED" -ForegroundColor Red;
    Write-Host "Error during 01. Load modules execution" -ForegroundColor Red;
    Write-Host $_.Exception.Message -ForegroundColor Red;
	Break;
}



### Loading static methods
Write-Host "Loading static PowerShell methods ... " -NoNewline;
$basicConfiguration = {
	$v = 0;
	
	Try
	{
		Set-NetFirewallProfile -Enabled false -Name Domain -PassThru
		Set-NetFirewallProfile -Enabled false -Name Private -PassThru
		
		Get-Service bits,wuauserv | Stop-Service -PassThru | Set-Service -StartupType disabled
		
		$v = 1;
	}
	Catch
	{
		$v = 0;
	}
	
	return $v;
}
Write-Host "DONE" -ForegroundColor Green;