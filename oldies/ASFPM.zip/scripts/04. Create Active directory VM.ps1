### Creating Active directory VM
Write-Host "Creating virtual machine $activeDirectory_Name ... " -NoNewline
Write-Host "STARTED" -ForegroundColor Yellow;
Try
{
    $vm = Get-AzureVM -ServiceName $cloudService_Name -Name $activeDirectory_Name;
	If ($vm -eq $null)
	{	
	    $image = GetAzureLatestImage -imageLabel $activeDirectory_ImageLabel;
	    CreateAzureVM -vm_Name $activeDirectory_Name -vm_Size $activeDirectory_Size -vm_Image $image -vNet $virtualNetwork_Name -subnet_Name $subnet_Name -admin_Username $activeDirectory_LocalAdministrator_Username -admin_Password $activeDirectory_LocalAdministrator_Password -cloudservice_Name $cloudservice_Name -affinityGroup_Name $affinityGroup_Name -domain_Name $null -domain_NetBiosName $null -domainAdmin_Name $null -domainAdmin_Password $null -vm_Ip $activeDirectory_IP
        
        Write-Host "Creating virtual machine $activeDirectory_Name ... " -NoNewline
	    Write-Host "DONE" -ForegroundColor Green;
		
		Write-Host "Sleeping for 1 minute ... "
		Start-Sleep 60;
    }
    Else
	{
        Write-Host "Creating virtual machine $activeDirectory_Name ... " -NoNewline
		Write-Host "LOADED PREEXISTING ONE" -ForegroundColor Yellow;
	}
}
Catch [Exception]
{
    Write-Host "Creating virtual machine $activeDirectory_Name ... " -NoNewline
    Write-Host "FAILED" -ForegroundColor Red;
    Write-Host "Error during 04. Create Active directory VM" -ForegroundColor Red;
    Write-Host $_.Exception.Message -ForegroundColor Red;
	Break;
}