### Creating SQL Server VM
Write-Host "Creating virtual machine $sqlServer_Name ... " -NoNewline
Write-Host "STARTED" -ForegroundColor Yellow;
Try
{
    $vm = Get-AzureVM -ServiceName $cloudService_Name -Name $sqlServer_Name;
	If ($vm -eq $null)
	{	
	    $image = GetAzureLatestImage -imageLabel $sqlServer_ImageLabel;
        CreateAzureVM -vm_Name $sqlServer_Name -vm_Size $sqlServer_Size -vm_Image $image -vNet $virtualNetwork_Name -subnet_Name $subnet_Name -admin_Username $sqlServer_LocalAdministrator_Username -admin_Password $sqlServer_LocalAdministrator_Password -cloudservice_Name $cloudservice_Name -affinityGroup_Name $affinityGroup_Name -domain_Name $domain_DomainName -domain_NetBiosName $domain_NetBiosName -domainAdmin_Name $administrator_Username -domainAdmin_Password $administrator_Password -vm_Ip $sqlServer_IP
        Write-Host "Creating virtual machine $sqlServer_Name ... " -NoNewline
	    Write-Host "DONE" -ForegroundColor Green;
		
		Write-Host "Sleeping for 1 minute ... "
		Start-Sleep 60;
    }
    Else
	{
        Write-Host "Creating virtual machine $sqlServer_Name ... " -NoNewline
		Write-Host "LOADED PREEXISTING ONE" -ForegroundColor Yellow;
	}
}
Catch [Exception]
{
    Write-Host "Creating virtual machine $sqlServer_Name ... " -NoNewline
    Write-Host "FAILED" -ForegroundColor Red;
    Write-Host "Error during 06. Create SQL server VM" -ForegroundColor Red;
    Write-Host $_.Exception.Message -ForegroundColor Red;
	Break;
}
