### Loading Azure subscription
Write-Host "Loading Azure subscription $subscription_Name ... " -NoNewline;
Write-Host "STARTED" -ForegroundColor Yellow;
Try
{
	Select-AzureSubscription –SubscriptionName $subscription_Name 

    Write-Host "Loading Azure subscription $subscription_Name ... " -NoNewline;
	Write-Host "DONE" -ForegroundColor Green;
}
Catch [Exception]
{
    Write-Host "Loading Azure subscription $subscription_Name ... " -NoNewline;
	Write-Host "FAILED" -ForegroundColor Red;
    Write-Host "Error during 03. Create infrastructure execution" -ForegroundColor Red;
    Write-Host $_.Exception.Message -ForegroundColor Red;
	Break;
}



### Creating Affinity group
Write-Host "Creating Affinity group $affinityGroup_Name ... " -NoNewline;
$affinityGroup = $null;
Try
{
    $affinityGroup = Get-AzureAffinityGroup -Name $affinityGroup_Name -ErrorAction SilentlyContinue;
	
    If ($affinityGroup -eq $null)
    {
        $affinityGroup = New-AzureAffinityGroup -Name $affinityGroup_Name -Location $affinityGroup_Location -ErrorAction SilentlyContinue;
        Write-Host "DONE" -ForegroundColor Green;
    }
	Else
	{
		Write-Host "LOADED PREEXISTING ONE" -ForegroundColor Yellow;
	}
}
Catch [Exception]
{
    Write-Host "FAILED" -ForegroundColor Red;
    Write-Host "Error during 03. Create infrastructure execution" -ForegroundColor Red;
    Write-Host $_.Exception.Message -ForegroundColor Red;
	Break;
}



### Creating Storage account
Write-Host "Creating Storage account $storageAccount_Name ... " -NoNewline;
$storageAccount = $null; 
Try
{
	$storageAccount = Get-AzureStorageAccount -StorageAccountName $storageAccount_Name -ErrorAction SilentlyContinue;

    If ($storageAccount -eq $null)
    {
        $storageAccount = New-AzureStorageAccount -StorageAccountName $storageAccount_Name -AffinityGroup $affinityGroup_Name;
		Write-Host "DONE" -ForegroundColor Green;
    }
	Else
	{
		Write-Host "LOADED PREEXISTING ONE" -ForegroundColor Yellow;
	}

    Set-AzureSubscription -SubscriptionName $subscription_Name -CurrentStorageAccount $storageAccount_Name
}
Catch [Exception]
{
    Write-Host "FAILED" -ForegroundColor Red;
    Write-Host "Error during 03. Create infrastructure execution" -ForegroundColor Red;
    Write-Host $_.Exception.Message -ForegroundColor Red;
	Break;
}



### Creating Virtual network
Write-Host "Creating Virtual network $virtualNetwork_Name ... " -NoNewline;
Try
{
	CreateAzureVirtualNetwork -vNet_Name $virtualNetwork_Name -vNet_AddressPrefix $virtualNetwork_AddressPrefix -vNet_Dns_Name $dns_Name -vNet_Dns_Ip $dns_Ip -vNet_Subnet_Name $subnet_Name -vNet_Subnet_AddressPrefix $subnet_AddressPrefix -affinityGroup_Name $affinityGroup_Name;
	Write-Host "DONE" -ForegroundColor Green;
}
Catch
{
    Write-Host "FAILED" -ForegroundColor Red;
    Write-Host "Error during 03. Create infrastructure execution" -ForegroundColor Red;
    Write-Host $_.Exception.Message -ForegroundColor Red;
	Break;
}



### Creating Cloud service
[console]::write("Creating Cloud service $cloudservice_Name ... ");
$cloudService = $null;
Try
{
	$cloudService = Get-AzureService -ServiceName $cloudservice_Name -ErrorAction SilentlyContinue;

    If ($cloudService -eq $null)
    {
        $cloudService = New-AzureService -ServiceName $cloudservice_Name -AffinityGroup $affinityGroup_Name;
		Write-Host "DONE" -ForegroundColor Green;
    }
	Else
	{
		Write-Host "LOADED PREEXISTING ONE" -ForegroundColor Yellow;
	}
}
Catch
{
    Write-Host "FAILED" -ForegroundColor Red;
    Write-Host "Error during 03. Create infrastructure execution" -ForegroundColor Red;
    Write-Host $_.Exception.Message -ForegroundColor Red;
	Break;
}