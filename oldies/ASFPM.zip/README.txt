README
-------------

Hi, if  you're reading this file you have choose my script to deploy, provision and deprovision a SharePoint 2013 farm on Azure.

Before starting the script you have to:

1. Enable PSRemoting on your client PC (run every command separately)
	Set-ExecutionPolicy ByPass 
	Enable-PSRemoting 
	Enable-WSManCredSSP -role client -delegatecomputer "*.cloudapp.net"  

	$regKey = "HKLM:\SYSTEM\CurrentControlSet\Control\Lsa\Credssp\PolicyDefaults\AllowFreshCredentialsDomain" 
	Set-ItemProperty $regKey -Name WSMan -Value "WSMAN/*.cloudapp.net"  

	Get-AzureSubscription -ExtendedDetails 
	
	Run GPEdit.msc. 
	You must also enable delegating of fresh credentials using group policy editor on your client machine. 
	Computer Configuration -> Administrative Templates -> System -> Credentials Delegation and then change 
	the state of "Allow Delegating Fresh Credentials with NTLM-only server authentication" to "Enabled." 
	Its default state will say, "Not configured."
	In the Add Servers sections add the following.
	WSMAN/*.cloudapp.net

2. Download and Install the Windows Azure PowerShell cmdlets

3. Download Azure settings file	
	Set-ExecutionPolicy RemoteSigned
	Import-Module Azure
	Get-AzurePublishSettingsFile

	Download the file whenever you want
	Import-AzurePublishSettingsFile <whenever_you_want>

	
4. Configure Config.xml as you want or create another file <name>.xml (e.g. development.xml, integration.xml)


Right now you can use the three scripts:
	- Build: builds a SharePoint 2013 farm from scratch
	- Deprovision: deprovision and deallocate the farm (so you can save your money)
	- Reprovision: reprovision and reallocate the farm 

May the force be with you.

Best regards,
Varro














